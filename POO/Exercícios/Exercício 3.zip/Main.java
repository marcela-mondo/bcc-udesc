import java.util.Scanner;
import java.util.Arrays;

public class Main{
  public static void main(String[] args){
    //System.out.println("Digite uma opção");
    Scanner var = new Scanner(System.in);
    Integer opcao = var.nextInt();

    switch(opcao){
        case 1:
            Integer num;
            do{
                System.out.println("\nDigite um número inteiro positivo: ");
                num = var.nextInt();
            } while(num<0);

            Integer array[] = new Integer[num];
            for(int i=0; i<num; i++){
                System.out.println("\nDigite um número inteiro: ");
                array[i] = var.nextInt();
            }

            Arrays.sort(array);
            for(int i=0; i<num; i++){
                System.out.println(array[i] + " ");
            }
            break;

      case 2:
          //System.out.println("Digite um valor para n: ");
          Integer n = var.nextInt();
          //System.out.println("Digite um valor para m: ");
          Integer m = var.nextInt();
          Integer matriz[][] = new Integer[n][m];

          for(int i=0; i<n; i++){
              for(int j=0; j<m; j++){
                  //System.out.println("Elemento [" + (i+1) + ":" + (j+1) + "]");
                  matriz[i][j] = var.nextInt();
              }
          }

          for(int i=0; i<n; i++){
              for(int j=0; j<m; j++){
                  System.out.print(matriz[i][j] + " ");
              }
              System.out.println();
          }
          break;

      case 3:
          //System.out.println("Digite um valor para n: ");
          n = var.nextInt();
          Integer det[][] = new Integer[n][n];

          for(int i=0; i<n; i++){
              for(int j=0; j<n; j++){
                  //System.out.println("Elemento [" + (i+1) + ":" + (j+1) + "]");
                  det[i][j] = var.nextInt();
              }
          }
          Integer determinante = 0;
          if(n == 1){
                determinante = det[0][0];
          }

          if(n == 2){
            determinante = (det[0][0] * det[1][1] - (det[0][1] * det[1][0]));
          }

          else {
                    Integer matrizAux[][] = new Integer[n - 1][n - 1];
                    for (int x = 0; x < n; x++) {
                        for (int i = 1; i < n; i++) {
                            int novoJ = 0;
                            for (int j = 0; j < n; j++) {
                                if (j == x) {
                                    continue;
                                }
                                matrizAux[i - 1][novoJ] = det[i][j];
                                novoJ++;
                            }
                        }

                        int detSubmatriz = 0;
                        if (n - 1 == 2) {
                            detSubmatriz = matrizAux[0][0] * matrizAux[1][1] - (matrizAux[0][1] * matrizAux[1][0]);
                        } else if (n - 1 == 1) {
                            detSubmatriz = matrizAux[0][0];
                        }
                        int cofactor = (int) Math.pow(-1, x) * det[0][x];
                        determinante += cofactor * detSubmatriz;
                    }
                }
                System.out.println(determinante);
                break;

        case 4:
            //System.out.println("Digite um valor para n: ");
        n = var.nextInt();
        //System.out.println("Digite um valor para m: ");
        m = var.nextInt();
        Integer mA[][] = new Integer[n][m];
        Integer mB[][] = new Integer[n][m];
        Integer soma[][] = new Integer[n][m];

        //System.out.println("Matriz A:");
        for(int i=0; i<n; i++){
              for(int j=0; j<m; j++){
                  //System.out.println("Elemento [" + (i+1) + ":" + (j+1) + "]");
                  mA[i][j] = var.nextInt();
              }
          }

        //System.out.println("Matriz B:");
        for(int i=0; i<n; i++){
              for(int j=0; j<m; j++){
                  //System.out.println("Elemento [" + (i+1) + ":" + (j+1) + "]");
                  mB[i][j] = var.nextInt();
              }
          }

        for(int i=0; i<n; i++){
              for(int j=0; j<m; j++){
                  soma[i][j] = mA[i][j] + mB[i][j];
              }
          }

        for(int i=0; i<n; i++){
              for(int j=0; j<m; j++){
                  System.out.print(soma[i][j] + " ");
              }
              System.out.println();
          }
      break;

      case 5:
        //System.out.println("Digite um valor para n: ");
        n = var.nextInt();
        //System.out.println("Digite um valor para m: ");
        m = var.nextInt();
        Integer m1[][] = new Integer[n][m];
        Integer m2[][] = new Integer[m][n];
        Integer mult[][] = new Integer[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                mult[i][j] = 0;
            }
        } 

        //System.out.println("Matriz A:");
        for(int i=0; i<n; i++){
              for(int j=0; j<m; j++){
                  //System.out.println("Elemento [" + (i+1) + ":" + (j+1) + "]");
                  m1[i][j] = var.nextInt();
              }
          }

        //System.out.println("Matriz B:");
        for(int i=0; i<m; i++){
              for(int j=0; j<n; j++){
                  //System.out.println("Elemento [" + (i+1) + ":" + (j+1) + "]");
                  m2[i][j] = var.nextInt();
              }
          }

        for(int i=0; i<n; i++){
          for(int j=0; j<n; j++){
            for(int x=0; x<m; x++){
              mult[i][j] += m1[i][x]*m2[x][j];
            }
          }
        }

        for(int i=0; i<n; i++){
          for(int j=0; j<n; j++){
            System.out.print(mult[i][j] + " ");
          }
          System.out.println();
        }
        
        break;

        
        }
    var.close();
    }
}