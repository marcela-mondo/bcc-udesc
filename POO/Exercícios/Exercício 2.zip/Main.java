import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    System.out.print("Digite uma opção: ");
    Scanner var = new Scanner(System.in);
    int opcao = var.nextInt();

    switch(opcao){
      case 1:
        System.out.print("\nDigite um número inteiro: ");
        int num = var.nextInt();
        if(num>10){
          System.out.println("\nMAIOR");
        }else{
            System.out.println("\nMENOR");
        }
        break;

      case 2:
        System.out.print("\nDigite um número inteiro: ");
        num = var.nextInt();  
        if(num % 2 == 0){
          num = num * 5;
        }
        
          if(num % 3 == 0){
            num = (num - 1);
          }
        
        System.out.println("\n" + num);
        break;

      case 3:
        do{
          System.out.print("\nDigite um número inteiro: ");
          num = var.nextInt();
        }while(num < 0);
        var.nextLine();

        String resultado = "";
        for(int i = 0; i<num; i++){
          System.out.print("\nPalavra " + (i+1) + ": ");
          String string = var.nextLine();
          resultado = string + " " + resultado;
        }
          System.out.println("\n" + resultado);
        break;

      case 4:
        int num2;
        do{
          System.out.print("\nPrimeiro número inteiro positivo: ");
          num = var.nextInt();
          System.out.print("\nSegundo número inteiro positivo: ");
          num2 = var.nextInt();
        }while((num | num2)<0); 
        
        int resto;
        while(num2 != 0){
          resto = num % num2;
          num = num2;
          num2 = resto;
        }

        System.out.println("\n" + num);
        break;

      case 5:
        int soma = 0;
        System.out.println("\nDigite os números");
        while(var.hasNextInt()){
          num = var.nextInt();
          soma = soma + num;
        }
        System.out.println("\n" + soma);
        break;
        
      default:
        System.exit(0);
      
    }
    var.close();
  }
}