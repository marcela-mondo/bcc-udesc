public class main{
    public static void main(String[] args){
        int numero = 2, dividir;
        
        for(numero=2; numero<100; numero++){
        
        boolean primo = true;
        for(dividir=2; dividir<numero; dividir++){
            if(numero % dividir == 0){
                primo = false;
                break;
            }
        }
        if(primo){
            System.out.print(numero);
            System.out.print(" ");
        }
    }
    }   
}