public class Radio{
   
   String estacao;
   int canal;
   int volume;
   
   public Radio(String estacao) {
   		this.estacao = estacao;
   		if ("AM".equals(estacao)) this.canal = 20;
        else if ("FM".equals(estacao)) this.canal = 80;
        this.volume = 0;
   }
   
       public String getEstacao() {
        return estacao;
    }

    public void setEstacao(String estacao) {
        this.estacao = estacao;
    }

    public int getCanal() {
        return canal;
    }

    public void setCanal(int canal) {
        this.canal = canal;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        if (volume < 0) this.volume = 0;
        else if (volume > 100) this.volume = 100;
        else this.volume = volume;
    }

    public void AumentarVolume() {
        if ((volume + 10) <= 100) {
            volume += 10;
        } 
        else volume = 100;
    }

    public void DiminuirVolume() {
        if ((volume - 10) >= 0) {
            volume -= 10;
        } 
        else volume = 0;
    }
}