public class Moto extends Veiculo{

	int cilindradas;

    public Moto(int ano, int chassi, float preco, float SemParar, int cilindradas) {
        super(ano, chassi, preco, SemParar); 
        this.cilindradas = cilindradas;
    }

    @Override
    public void PagarPedagio() {
        float valorPedagio = 10;
        float saldoAtual = getSemParar();
    
        if (saldoAtual >= valorPedagio) {
            setSemParar(saldoAtual - valorPedagio);
            System.out.println("Dinheiro: " + getSemParar());
        } else {
            System.out.println("Moto sem dinheiro suficiente");
        }
    }

    public int getcilindradas() {
        return cilindradas;
    }

    public void setcilindradas(int cilindradas) {
        this.cilindradas = cilindradas;
    }
    
}