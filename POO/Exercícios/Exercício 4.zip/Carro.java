
public class Carro extends Veiculo{

    boolean automatico;
    public Radio frequencia;
    public Radio amplitude;

    public Carro(int ano, int chassi, float preco, float SemParar, boolean automatico) {
        super(ano, chassi, preco, SemParar); 
        this.automatico = automatico;
        this.frequencia = new Radio("FM");
        this.amplitude = new Radio("AM");
    }


    @Override
    public void PagarPedagio() {
        float valorPedagio = 20;
        float saldoAtual = getSemParar();
    
        if (saldoAtual >= valorPedagio) {
            setSemParar(saldoAtual - valorPedagio);
            System.out.println("Dinheiro: " + getSemParar());
        } else {
            System.out.println("Carro sem dinheiro suficiente!");
        }
    }
  
    public boolean getAutomatico() {
        return automatico;
    }

    public void setAutomatico(boolean automatico) {
        this.automatico = automatico;
    }

    public Radio getFrequencia() {
        return frequencia;
    }

    public void setFrequencia(Radio frequencia) {
        this.frequencia = frequencia;
    }

    public Radio getAmplitude() {
        return amplitude;
    }

    public void setAmplitude(Radio amplitude) {
        this.amplitude = amplitude;
    }
}
