

public class Caminhao extends Veiculo{

	int CapacidadeTotal;
	int CapacidadeAtual;
    public Caminhao(int ano, int chassi, float preco, float SemParar, int CapacidadeTotal) {
        super(ano, chassi, preco, SemParar);         this.CapacidadeTotal = CapacidadeTotal;
        this.CapacidadeAtual = 0;
    }
    public int getCapacidadeTotal() {
        return CapacidadeTotal;
    }

    public void setCapacidadeTotal(int CapacidadeTotal) {
        this.CapacidadeTotal = CapacidadeTotal;
    }

    public int getCapacidadeAtual() {
        return CapacidadeAtual;
    }

    public void setCapacidadeAtual(int CapacidadeAtual) {
        if (CapacidadeAtual <= this.CapacidadeTotal) this.CapacidadeAtual = CapacidadeAtual;
    	else System.out.println("Carga excedida!");
    }
    
    @Override
    public void PagarPedagio() {
        float valorPedagio = 40;
        float saldoAtual = getSemParar();
    
        if (saldoAtual >= valorPedagio) {
            setSemParar(saldoAtual - valorPedagio);
            System.out.println("Dinheiro: " + getSemParar());
        } else {
            System.out.println("Caminhão sem dinheiro suficiente");
        }
    }

 
}