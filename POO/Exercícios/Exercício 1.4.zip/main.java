public class main{
    public static void main(String[] args){
    int auxiliar=1, a=0, b=1;
    
    System.out.print(0 + " ");
    
    for(int i=0;i<100;i++){
        if (auxiliar<100){
            System.out.print(auxiliar + " ");
            auxiliar = a + b;
            a = b;
            b = auxiliar;
        }
    }
    }
}