public class main{
    public static void main(String[] args){
        for(int x=0; x<=1; x++){
            for(int y=0; y<=1; y++){
                for(int z=0; z<=1; z++){
                    boolean xb = x == 1;
                    boolean yb = y == 1;
                    boolean zb = z == 1;
                    boolean resultado = xb && yb || zb;
                    System.out.print(xb + " e " + yb + " ou " + zb + " = " + resultado);
                    System.out.println();
                    
                }
            }
        }
    }
}